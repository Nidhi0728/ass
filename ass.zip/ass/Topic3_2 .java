import java.util.*;
import java.lang.*;
class Topic3_2 
{  

    public static void main(String[] args)
     {
       String name=args[0];
        int average=0;
        try
        {
         int m1=Integer.parseInt(args[1]);
         int m2=Integer.parseInt(args[2]);
         int m3=Integer.parseInt(args[3]);
         average=(m1+m2+m3)/3;
         System.out.println("Name of student="+name);
         System.out.println("average marks of student="+average);
         
      
        }
        catch(NumberFormatException ex)
           {
             System.out.println("only integer number");
             System.exit(0);
           }



     }
}