import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class calculators extends JFrame implements ActionListener
{
	JLabel lblfirst,lblsecond,lblresult;
	JTextField txtfirst,txtsecond,txtresult;
	JButton btnadd,btnsub,btnmulti,btndiv,btnrem,btnreset,btnexit;
	Container con;
	calculators()
	{
		setTitle("CALCULATOR");
		con=getContentPane();
		lblfirst=new JLabel("First number");
		lblsecond=new JLabel("Second number");
		lblresult=new JLabel("Result");
		txtfirst=new JTextField(10);
		txtsecond=new JTextField(10);
		txtresult=new JTextField(10);
		btnadd=new JButton("+");
		btnsub=new JButton("-");
		btnmulti=new JButton("*");
		btndiv=new JButton("/");
		btnrem=new JButton("%");
		btnreset=new JButton("Reset");
		btnexit=new JButton("Exit");
		con.setLayout(new FlowLayout());
		con.add(lblfirst);con.add(txtfirst);
		con.add(lblsecond);con.add(txtsecond);
		con.add(lblresult);con.add(txtresult);
		con.add(btnadd);con.add(btnsub);
		con.add(btnmulti);con.add(btndiv);con.add(btnrem);
		con.add(btnreset);con.add(btnexit);
		con.setBackground(Color.magenta);
		setSize(400,400);
		show();//setVisible(true);
		//pack();
		btnadd.addActionListener(this);
		btnsub.addActionListener(this);
		btnmulti.addActionListener(this);
		btndiv.addActionListener(this);
		btnrem.addActionListener(this);
		btnreset.addActionListener(this);
		btnexit.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent ae)
	{ 
		int a,b,rs;
		//a=Integer.parseInt(txtfirst.getText());
		//b=Integer.parseInt(txtsecond.getText());
		if(ae.getSource()==btnadd)
		{
			a=Integer.parseInt(txtfirst.getText());
			b=Integer.parseInt(txtsecond.getText());
			rs=a+b;
			txtresult.setText(rs+"");
		}
		else if(ae.getSource()==btnsub)
		{
			a=Integer.parseInt(txtfirst.getText());
			b=Integer.parseInt(txtsecond.getText());
			rs=a-b;
			txtresult.setText(Integer.toString(rs));
		}
		else if(ae.getSource()==btnmulti)
		{
			a=Integer.parseInt(txtfirst.getText());
			b=Integer.parseInt(txtsecond.getText());
			rs=a*b;
			txtresult.setText(rs+"");
		}
		else if(ae.getSource()==btndiv)
		{
			a=Integer.parseInt(txtfirst.getText());
			b=Integer.parseInt(txtsecond.getText());
			rs=a/b;
			txtresult.setText(rs+"");
		}
			else if(ae.getSource()==btnrem)
		{
			a=Integer.parseInt(txtfirst.getText());
			b=Integer.parseInt(txtsecond.getText());
			rs=a%b;
			txtresult.setText(rs+"");
		}
		else if(ae.getSource()==btnreset)
		{
			txtfirst.setText("");
			txtsecond.setText("");
			txtresult.setText("");
			txtfirst.requestFocus();
		}
		else if(ae.getSource()==btnexit)
		{
			//setDefaultCloseOperation(JFrame.dispose());
			System.exit(0);
		}
	}
	public static void main(String args[])
	{
		calculators obj=new calculators();
	}
}
		
		

