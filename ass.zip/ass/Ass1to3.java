import java.util.*;
import java.lang.*;
class Ass2
{
   public void show()
   {
      int a=-5;
      int b=8;
      int c=6;
     System.out.println(a+b*c);
     
   }
  public void show1()
   {
     int a=9;
    int b=55;
    System.out.println((b+a)%a);
  }
  public void show2()
    {
     int a=20;
     int b=-3;
    int  c=5;
    int d=8;
   System.out.println(a+b*c/d);
  }
  public void show3()
   {
     int a=5;
     int b=15;
     int c=3;
     int d=2;
     int e=8;
      System.out.println(a+b/c*d-e%3);


   }
 
}
class Ass1to3
{
  public static void main(String[] args)
   {
      System.out.println("Welcome to Java Programming");
      Scanner obj_name=new Scanner(System.in);
      System.out.println("enter minutes to cal days and years");
      float min=obj_name.nextFloat();
      System.out.println(min);
      Ass2 obj=new Ass2();
      obj.show();
     obj.show1();
     obj.show2();
     obj.show3();
     float hours=min/60;
     float days=hours/24;
     float years=days/365;
    System.out.println(days);
   System.out.println(hours);
   System.out.println(years);

   }
}