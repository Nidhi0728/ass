package music1.wind1;
import music1.Playable;
public class Saxophone implements Playable
{
  public void play()
   {
      System.out.println("doneeeee");
   }
}