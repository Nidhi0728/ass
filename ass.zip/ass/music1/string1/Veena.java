package music1.string1;
import music1.Playable;
public class Veena implements Playable
{
  public void play()
   {
      System.out.println("done");
   }
}