package music1;
import java.util.*;
public interface Playable
{
  public void play();
}