class Book
{
  int isbn;
  String title;
  float price;

}
class Magazine extends Book
{
  String type;
  public Magazine (int b, String t, float p, String ty)
  {
      isbn=b;
     title=t;
    price=p;
    type=ty;
 
  }
public void  display()
{
  System.out.println("ISBN of ="+isbn);
  System.out.println("title of ="+title);
  System.out.println("type of ="+type);
 System.out.println("price of ="+price);

}
}
class Novel extends Book
{
  String author;
  public Novel (int b, String t, float p, String a)
  {
      isbn=b;
     title=t;
    price=p;
    author=a;
 
  }
public void display()
{
  System.out.println("ISBN of ="+isbn);
  System.out.println("title of ="+title);
  System.out.println("author of ="+author);
 System.out.println("price of ="+price);

}
}
class Book1
{
  public static void main(String args[])
 {
    Magazine m1 = new Magazine(123, "Good Men are hard to define",999.23f,"social");
    m1.display();
   System.out.println("*******************************************************************\n");
    Novel n1=new Novel(1000,"Three Mistake Of Life",1234.45f,"Chetan Bhagat");
   n1.display();

 }
}
