import java.util.*;
import java.lang.*;
class Topic3_4 
{  
    public static void main(String args[])
    {
        String a = "Malyalam";
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the Character:");
        char c=s.next().charAt(0);
       int l=a.length;
       int count =0;
       for(int i=0;i<l;i++)
       {
          if(a.charAt(i)==c)
           {
            count++;
           }
       }
     System.out.println("total Count is ="+count);
      
    }
}