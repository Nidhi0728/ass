import java.util.*;
import java.lang.*;
class Check
{
	public static void main(String arg[])
	{
          int a=10;
          int b=20;
	   int c=34;
           	
	   HashMap<String, Integer> hm=new HashMap<String, Integer>();
	   hm.put("a",10);
           hm.put("b",20);
	   hm.put("c",34);
 
	   System.out.println(hm);
	}
}