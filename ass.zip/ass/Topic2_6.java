package live;
import music1.Playable;
import music1.string1.Veena;
import music1.wind1.Saxophone;
class Topic2_6
{
   public static void main(String[] args)
   {
     Veena obj=new Veena();
     Saxophone obj1=new Saxophone();
      obj.play();
     obj1.play();
   }
}