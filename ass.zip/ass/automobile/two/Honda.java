package automobile.two;
public class Honda extends automobile.Vehicle
{
  public String modelName()
   {
     String mName="Honda1";
     return mName;
   }
  public String registrationNumber()
   {
     String mNumber="123400";
     return mNumber;
   }
  public String ownerName()
   {
     String mName1="HondaExp";
     return mName1;
   }
  public int speed()
  {
    int speed=120;
    return speed;
  }
  public void radio()
  {
    System.out.println("provide Facility to control radio device of Honda");
  }
}