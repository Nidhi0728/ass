package automobile.two;
public class hero extends automobile.Vehicle
{
  public String modelName()
   {
     String mName="xyz";
     return mName;
   }
  public String registrationNumber()
   {
     String mNumber="12345";
     return mNumber;
   }
  public String ownerName()
   {
     String mName1="papa";
     return mName1;
   }
  public int speed()
  {
    int speed=80;
    return speed;
  }
  public void radio()
  {
    System.out.println("provide Facility to control radio device");
  }

}