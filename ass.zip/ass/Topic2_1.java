class Book
{
  String author;
  int price;
   String title;
  int _isbn;
  int dis_price;

  public Book(int p,String t,String a,int bn)
  {
    _isbn=bn;
    price=p;
    title=t;
    author=a;
  }
 public void displaydeta_ils()
  {
     dis_price= discount(10);
    System.out.println("ISBN


 of the book="+_isbn);
    System.out.println("Title of the book="+title);
   System.out.println("Author of the book="+author);
  System.out.println(" Price of the book="+price);
  
  System.out.println(" Price of the book="+dis_price);
 
  
    
 }
 public int discount(int dis)
 {
   int c=price*dis/100;
   return(price-c);
  } 
}
class Topic2_1
{
 public static void main(String args[])
 {
   Book b1=new Book(230,"The Book","Ravindra Nath",123);
   b1.displaydeta_ils();
 }
}
  
