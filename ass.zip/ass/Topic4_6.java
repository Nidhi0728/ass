import java.util.*;
import java.lang.*;
class test
{
   public void finalize()
   {
    System.out.println("Finalized is called");
   }
}
public class Topic4_6 
{
  public static void main(String[] args)
  {
    test a=new test();
     a=new test();
     a=new test();
    a.finalize();
     Runtime.getRuntime().gc();
  }
}
