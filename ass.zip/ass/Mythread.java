import java.util.*;
import java.lang.*;
class random extends Thread
{
   Random rand = new Random();
   int rand_number;
   public void run()
    {       
      for(int i=0;i<5;i++)
       {
           rand_number=rand.nextInt(1000);
         System.out.println(rand_number);
       }
      
    }
}
class factorial extends Thread
{
   
   public void run()
    {   
      int j=0;
      while(j<5)
      {
         int num=5;
        int fact=1;
       for(int i=1;i<=5;i++)
        {
        fact=fact*i;
        }
      System.out.println("factorial is="+fact);
      j++;
     }
   }
}
public class Mythread
{
  public static void main(String[] args)
   {
      random obj=new random();
      factorial obj1=new factorial();
      obj.start();
      obj1.start();
   }
}