import java.util.*;
import test.foundation;
public class Topic5_1 
{
  public static void main(String[] args)
  {
     foundation obj=new foundation();
     obj.show();
     int s=obj.v2;
    int s1=obj.v3;
     int s2=obj.v4;
    System.out.println(s);   
    System.out.println(s1);   
    System.out.println(s2);
  }
}