import java.util.*;
import java.lang.*;
class RandomTime extends Thread
{
   
   public void run()
    {       
      for(int i=2000;i<=40000;)
       {
          System.out.println(java.time.LocalTime.now());
         try{ Thread.sleep(2000);} catch(Exception e){}
         i=i+4000;   
       }
      
    }
}
public class Time
{
   public static void main(String[] args)
   {
     RandomTime obj=new RandomTime();
    obj.start();
   }
}