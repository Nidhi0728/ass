import java.util.*;
import foundation.twoWheeler.hero;
class test3
{
   public static void main(String[] args)
    {
      hero obj=new hero();

      obj.show1();
    
    }
}