abstract class Instrument
{
   abstract void play();
}
class Piano extends Instrument
{
   void play()
    {
      System.out.println("Piano is playing tan tan tan tan ");
    }
}
class  Flute extends Instrument
{
   void play()
    {
      System.out.println("Flute is playing toot toot toot toot");
    }
}
class  Guitar extends Instrument
{
   void play()
    {
      System.out.println("Guitar is playing tin tin tin " );
    }
}
class Instrument1
{
   public static void main(String args[])
   {
     Instrument[] s=new Instrument[10];
     s[0]=new Piano();
     s[1]=new Flute();
      s[2]=new Guitar();
      s[3]=new Piano();
     s[4]=new Flute();
     s[5]=new Guitar();
     s[6]=new Piano();
     s[7]=new Flute();
     s[8]= new Guitar();
     s[9]=new Piano();
    int count=0;
   
     for(int i=0;i<3;i++)
     {
      if(s[i] instanceof Piano)
      {
       s[i].play();
        count++;
        System.out.println("************************************");
      }
      else if(s[i] instanceof Flute)
       {
         s[i].play();
         
        System.out.println("***************@@@@@@*********************");
       }
     else if(s[i] instanceof Guitar)
      {
        s[i].play();
       
        System.out.println("***************&&&&&&&&*********************");
      }
     else
      {
         System.out.println("No Instrument!!!!!!!!!!!!!!!");
      }
     }
  System.out.println(count);
 
   }

}


