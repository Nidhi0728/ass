import java.util.*;
import java.lang.*;
import java.util.*;

public class HashSetEmp {
   public static void main(String args[]) 
    {      
      HashSet <String> Empset = new HashSet <String>();
      Empset.add("Nidhi"); 
      Empset.add("Khushi");
      Empset.add("Janat");  
      Iterator iterator = Empset.iterator(); 
      while (iterator.hasNext()) {
         System.out.println("EmpName: "+iterator.next() + " ");  
      }
   }    
}