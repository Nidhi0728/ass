import java.util.*;
import java.lang.*;
class Employee
{
        // TODO: Write your code Here
         int EmpID;
        String EmpName;
         String EmpAdress;
         int Age;
}
class EmployeeDb
{
   public List<Employee> Emplist=new ArrayList<>() ;
   public boolean addEmp(Employee e)
   { 
      boolean result=false;
      if(e!=null)
      {
       Emplist.add(e);
        result=true;
      }
    return result;
      
   }
   public boolean DeleteEmp(int eCode)
   { 
      boolean result=false;
      for(int i=0; i<Emplist.count;i++)
       {
         if(Emplist.EmpID==eCode)
          {
             Emplist.removeAt(i);
             result=true;
          }
       }
      return result;
      
   }
   
}
public class Topic4_3 
{
  public static void main(String[] args)
   {
     Employee obj=new Employee();
     obj.EmpID=123;
    obj.EmpName="nidhi";
    obj.EmpAdress="patna";
    obj.Age=34; 
   EmployeeDb obj1=new EmployeeDb();
   boolean b= obj1.addEmp(obj);
   System.out.println(b);

   boolean c= obj1.DeleteEmp(123);
   System.out.println(c);
    
   }
}