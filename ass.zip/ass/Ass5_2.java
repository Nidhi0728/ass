import java.util.*;
import java.lang.*;
class Ass5_2
{
  public static void main(String[] args)
    { 
      String s="";
      String s1="tech";
      s=args[1];
      args[1]=s1;
      args[2]=s;
      System.out.println(args[0]);      
      System.out.println(args[1]);    
      System.out.println(args[2]);
      
    }
}