import java.util.*;
import java.lang.*;
class MyException extends Exception 
{ 
    public MyException(String s) 
    { 
       super(s);
        
    } 
    
} 
  
public class Topic3_1 
{
   int age;
   String Name;

public static void main(String args[])
 {
    String getage=args[0];
   String getname=args[1];
   int age1=Integer.parseInt(getage);
   Ass3_1 s=new Ass3_1();
   try
     {
	if(age1<18 || age1>60)
	 {
               MyException objAgeException =new MyException("Employee age should in the range of 18 and 58");
		throw objAgeException;
	  }
	else{
                 
                s.age=age1;
                s.Name=getname;
               System.out.println(s.age);
              System.out.println(s.Name);
	    }
	 }
	catch( MyException exp)
	{
	  System.out.println(exp);
          System.exit(0);
	}
      

   }
}


 
  