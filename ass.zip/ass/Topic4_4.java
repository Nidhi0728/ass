import java.util.HashMap;
import java.util.Scanner;
import java.lang.*;
public class Topic4_4 
{
  public static void main(String[] args)
   {
      Scanner s=new Scanner(System.in);
      HashMap<String,String> TelephonBook= new HashMap<String,String>();

       TelephonBook.put("NIDHI","8210652266");
       TelephonBook.put("NID","8210652200");
       TelephonBook.put("NIDH","8210652299");
       TelephonBook.put("NI","8210652244");
      TelephonBook.put("NISHA","8210652288");
      System.out.println("Enter Name");
      String name=s.nextLine().toUpperCase();
     if(TelephonBook.containsKey(name))
      {
        System.out.println(name+"mobile_number"+TelephonBook.get(name));
      }
      System.out.println(TelephonBook);
    
   }
}