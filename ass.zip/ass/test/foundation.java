package test;
public class foundation
{
   int v1=10;
  public int v2=30;
  protected int v3=45;
   default int v4=12;
  public void show()
  {
     System.out.println(v1);
  }
}