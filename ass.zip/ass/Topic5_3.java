import automobile.two.hero;
import automobile.two.Honda;
public class Topic5_1
{
   public static void main(String[] args)
   {
     hero obj=new hero();  

     String name= obj.modelName();
     String Oname=obj.ownerName();
    System.out.println(name);
    System.out.println(Oname);
    Honda obj1=new Honda();
    String name1= obj1.modelName();
     String Oname1=obj1.ownerName();
    System.out.println(name1);
    System.out.println(Oname1);
    
   }
}