import java.util.*;
class Ass5_6
{
   public static void main(String[] args)
    { 
      Scanner ob=new Scanner(System.in);
      System.out.println("enter only 4didg number");
      int num=ob.nextInt();
      int sum=0;
      int re=0;
      int[] arr={2,3,4,5,1};
       int s=arr[0];
      for(int i=0; i<arr.length;i++)
       {
         if(arr[i]>s)
          {
            s=arr[i];
          }
       }
       System.out.println("Biggest number is="+s);
     
      while(num>0)
        {
          re=num%10;
          sum=sum+re;
          num=num/10; 
        }
     System.out.println(sum);
    
    }
}