import java.util.*;
class Topic3_3 
{
   public static void main(String[] args)
     {   
        int avg=0;       
       for(int i=0; i<5;i++)
          {
               try
                 {
                    int a=Integer.parseInt(args[i]);
                     avg=avg+a;
                  }
                catch(ArrayIndexOutOfBoundsException ex)
                   {
                      System.out.println("Enter 5 values");
                      System.exit(0);
                    }
          }
        
       avg=avg/5;
      System.out.println(avg);        
     }
}